export const environment = {
  production: true,
  apiUrl: 'https://projectssdapiadmin20211126215408.azurewebsites.net/'
};
